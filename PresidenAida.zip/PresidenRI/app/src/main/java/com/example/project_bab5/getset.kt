
data class getset(
    var name: String = "", //untuk mendeklarasikan var name yang mengisi tipe data string
    var detail: String = "",
    var pict: Int = 0
)
